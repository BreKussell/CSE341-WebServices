const express = require('express');
const bodyParser = require('body-parser');
const host = 'localhost'
const port = 3000;
const app = express();
const mongoose = require('mongoose');
const user = require("./models/user");
const bcrypt = require('bcryptjs');
const jwt = require("jsonwebtoken");
const JWT_SECRET = "dj@ie1p3o1!*i4uxjflwe9e2pqqeiqbvvvc#$#lyqzcwi$ouer#&tymizq"

app.use(express.static('public'));

app.use(bodyParser.json());

app.post('/api/login', async (req, res) => {
    res.json({ status: "Good" })
})




mongoose.connect(' ',{
    useNewURLParser: true,
    useUnifiedTopology: true
})


/******************************************
 ****Register User
*******************************************/

app.post('/api/register', async (req, res) =>{
    const { username, password: plainTextPassword } = req.body
    if(!username || typeof username !== 'string' ) {
        return res.json({ status: 'error', error: 'Invalid username'  })
    }

    if(!plainTextPassword || typeof plainTextPassword !== 'string' ) {
        return res.json({ status: 'error', error: 'Invalid password'  })
    }

    if (plainTextPassword.length  < 8) {
        return res.json({ status: 'error', error: 'Password is too short. Make your password at least 8 characters long'  })
    }

    // hashing passwords
    const password = await bcrypt.hash(plainTextPassword, 10)
   // console.log(bcrypt.hash('password', 10))

 
try {
    const response = await user.create({
        username,
        password

    })

    console.log('User created successfully:', response)

} catch(error){
    //console.log(JSON.stringify)
    if (error.code === 11000) { //duplicate key/username
    return res.json({ status: "error", error: "This username is already in use"})


}
throw error
}
res.json({status: 'Good'})
})



app.post('/api/change-password', async (req, res) => {
    const { token, newpassword } = req.body;

    try {
        // Verify the JWT token and get the user data
        const decoded = jwt.verify(token, JWT_SECRET);
        const _id = decoded.id;  // Get user id from token payload

        // Hash the new password
        const hashedPassword = await bcrypt.hash(newpassword, 10);  // It's recommended to use salt rounds, e.g., 10

        // Use the User model to update the password in the database
        await User.updateOne({ _id }, {
            $set: { password: hashedPassword }
        });

        res.json({ status: "Good", message: "Password successfully updated" });
    } catch (error) {
        console.error("Error changing password:", error);
        res.status(500).json({ status: 'error', error: 'Something bad is happening' });
    }
});




/******************************************
 ****Login User
*******************************************/
const loginAttempts = {};

app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    // Initialize login attempts for the user if not already done
    if (!loginAttempts[username]) {
        loginAttempts[username] = 0;
    }

    // Check if the login attempts are greater than or equal to 5
    if (loginAttempts[username] >= 5) {
        return res.json({ status: 'error', error: 'Get thee hense hacker!' });
    }

    // Find user by username only
    const user = await User.findOne({ username }).lean();
    if (!user) {
        loginAttempts[username] += 1;
        return res.json({ status: 'error', error: 'Invalid username/password' });
    }

    // Compare hashed password
    if (await bcrypt.compare(password, user.password)) {
        loginAttempts[username] = 0; // Reset attempts on successful login
        const token = jwt.sign({
            id: user._id,
            username: user.username,
        }, JWT_SECRET);

        return res.json({ status: 'Good', data: token, message: 'Welcome obviously not suspicious person' });
    } else {
        loginAttempts[username] += 1;
        return res.json({ status: 'error', error: 'Invalid username/password' });
    }
});


app.post()


// Initialize database and start server

app.listen(port, () => {
     console.log(`Database and app listening on ${host}:${port}`)
})


